package com.suki.reg.bus.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.suki.core.beans.Customer;
import com.suki.reg.bus.RegisterBus;
import com.suki.reg.dao.RegisterDao;
@Service
public class RegisterBusImpl implements RegisterBus{

	@Autowired
	private RegisterDao dao;
	
	@Transactional
	public Long save(Customer customer) {
		return dao.save(customer);
		
	}

	
	

}
