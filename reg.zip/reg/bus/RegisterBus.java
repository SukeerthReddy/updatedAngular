package com.suki.reg.bus;

import com.suki.core.beans.Customer;

public interface RegisterBus {
	Long save(final Customer customer);

	

}
