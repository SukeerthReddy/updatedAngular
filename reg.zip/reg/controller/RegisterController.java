package com.suki.reg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.suki.core.beans.Customer;
import com.suki.reg.bus.RegisterBus;
@CrossOrigin("*")
@Controller
public class RegisterController {
	@Autowired
	private RegisterBus registerBus;
	
	@PostMapping("/api/customer/save")
	public ResponseEntity<?> save(@RequestBody final Customer customer)
	{
		Long id =registerBus.save(customer);
		return ResponseEntity.ok().body("customer is Created with id:"+id);
		
	} 
	
}
