package com.suki.reg.dao;

import com.suki.core.beans.Customer;

public interface RegisterDao {
	
	Long save(final Customer customer);
	


}
